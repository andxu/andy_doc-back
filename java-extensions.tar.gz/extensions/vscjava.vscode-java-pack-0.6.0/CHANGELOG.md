# Change Log

## 0.6.0
- Added [Visual Studio IntelliCode](https://marketplace.visualstudio.com/items?itemName=VisualStudioExptTeam.vscodeintellicode) to Java Extension Pack

## 0.4.0
- Added Overview page to help users get started
- Use extensionPack instead of extensionDependencies
- Updated README to provide more info to developers
- Added telemetry

## 0.3.0
- Added Java Test Runner and Maven Package Explorer to the pack

## 0.2.0
- Update the links for open source

## 0.1.0
- Initial release
